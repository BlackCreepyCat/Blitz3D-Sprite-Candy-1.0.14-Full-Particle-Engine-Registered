function embedFlash(fileName, width, height, backColor)
	{
	var maxWidth  = 400;
	var maxHeight = 400;
	if (!backColor) { backColor = '#000000'; }
	
	// CHECK IF FLASH MOVIE EXCEEDS ALLOWED DIMENSIONS
	if(width  > maxWidth)  { height = Math.round((maxWidth/width)   * height); width  = maxWidth;  }
	if(height > maxHeight) { width  = Math.round((maxHeight/height) * width);  height = maxHeight; }
	
	document.write('<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" \n');
	document.write('codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" \n');
	document.write('WIDTH  = "'+width +'"  \n');
	document.write('HEIGHT = "'+height+'"  \n');
	document.write('id     = "MOVIE" \n'); 
	document.write('ALIGN  = "CENTER"    > \n');
	document.write('<PARAM NAME = "MOVIE"   VALUE = "'+fileName+'"> \n');
	document.write('<PARAM NAME = "menu"    VALUE = "false"    > \n');
	document.write('<PARAM NAME = "quality" VALUE = "high"     > \n');
	document.write('<PARAM NAME = "scale"   VALUE = "exactfit" > \n');
	document.write('<PARAM NAME = "bgcolor" VALUE = "#FFFFFF"  > \n');
	document.write('<PARAM NAME = "wmode"   VALUE = "transparent"  > \n');
	document.write('<EMBED src="'+fileName+'" \n');
	document.write('menu    = false \n');
	document.write('quality = high \n');
	document.write('scale   = "exactfit" \n');
	document.write('swLiveConnect=true \n');
	document.write('bgcolor = #FFFFFF \n');
	document.write('WIDTH   = "'+width +'" \n');
	document.write('HEIGHT  = "'+height+'" \n');
	document.write('NAME    = "MOVIE" \n');
	document.write('TYPE    = "application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"> \n');
	document.write('</EMBED> \n');
	document.write('</OBJECT>');
	}
